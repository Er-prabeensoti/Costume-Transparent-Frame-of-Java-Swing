package com.java.frame;

import java.awt.EventQueue;
import java.awt.Frame;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowStateListener;
import java.awt.event.WindowEvent;
import java.awt.Toolkit;
import java.awt.Font;

public class CostumeFrame extends JFrame {

	private JPanel contentPane;
	private JLabel lblClose;
	private JLabel lblMaximize;
	private JLabel lblMinimize;
	
	static JFrame frame ;
	int tx=0,ty=0;
	private Boolean max;
	private JPanel ContaintPanel;
	private JLabel lblLogin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new CostumeFrame();
					//Remove the top bar
					frame.setUndecorated(true);
					
					frame.setResizable(true);
					frame.setBackground(new Color(0,0,0,65));
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CostumeFrame() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\prabe\\Downloads\\Compressed\\201550-education\\201550-education\\png\\brainstorm.png"));
		setTitle("LogIn");
		
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 100, 550, 370);
		contentPane = new JPanel();
		contentPane.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mousePressed(MouseEvent e) {
				tx= e.getX();
				ty=e.getY();	
				
			}
		});
		contentPane.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				frame.setLocation(e.getXOnScreen()-tx,e.getYOnScreen()-ty);
			
			}
		});
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setBackground(new Color(0,0,0));
		contentPane.add(getLblClose());
		contentPane.add(getLblMaximize());
		contentPane.add(getLblMinimize());
		contentPane.add(getContaintPanel());
		contentPane.add(getLblLogin());
	}
	private JLabel getLblClose() {
		if (lblClose == null) {
			lblClose = new JLabel("");
			lblClose.setHorizontalAlignment(SwingConstants.CENTER);
			lblClose.setBounds(12,6, 16, 16);
			max=false;
			lblClose.setIcon(new ImageIcon(getClass().getResource("/icon_resources/Close.png")));
				
			lblClose.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e) {
					lblClose.setIcon(new ImageIcon(getClass().getResource("/icon_resources/CloseHover.png")));
				}
				@Override
				public void mouseExited(MouseEvent e) {
					lblClose.setIcon(new ImageIcon(getClass().getResource("/icon_resources/Close.png")));
				}
			
				@Override
				public void mouseClicked(MouseEvent e) {
					System.exit(0);
				}
				
			});
		}
		return lblClose;
	}
	private JLabel getLblMaximize() {
		if (lblMaximize == null) {
			lblMaximize = new JLabel("");
			lblMaximize.setHorizontalAlignment(SwingConstants.CENTER);
			lblMaximize.setBounds(30,6, 16, 16);
			lblMaximize.setIcon(new ImageIcon(getClass().getResource("/icon_resources/MaxMin.png")));
			
			/*lblMaximize.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e) {
					if(!max) {
						lblMaximize.setIcon(new ImageIcon(getClass().getResource("/icon_resources/MaximizeHover.png")));
					}
					else{
						lblMaximize.setIcon(new ImageIcon(getClass().getResource("/icon_resources/ResizeHover.png")));
					}
					
				}
				@Override
				public void mouseExited(MouseEvent e) {
					lblMaximize.setIcon(new ImageIcon(getClass().getResource("/icon_resources/MaxMin.png")));
				}
			
				@Override
				public void mouseClicked(MouseEvent e) {
				if(!max) {
					max=true;
					frame.setExtendedState(JFrame.MAXIMIZED_BOTH);	
				}
				else if(max) {
					max=false;
					frame.setExtendedState(JFrame.NORMAL);
					
				}
				
				}
				
			});*/
		}
		return lblMaximize;
	}
	private JLabel getLblMinimize() {
		if (lblMinimize == null) {
			lblMinimize = new JLabel("");
			lblMinimize.setIcon(new ImageIcon(getClass().getResource("/icon_resources/Minimize.png")));
			lblMinimize.setHorizontalAlignment(SwingConstants.CENTER);
			lblMinimize.setBounds(48,6, 16, 16);
			
			
			
			lblMinimize.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e) {
					lblMinimize.setIcon(new ImageIcon(getClass().getResource("/icon_resources/MinimizeHover.png")));
				}
				@Override
				public void mouseExited(MouseEvent e) {
					lblMinimize.setIcon(new ImageIcon(getClass().getResource("/icon_resources/Minimize.png")));
				}
			
				@Override
				public void mouseClicked(MouseEvent e) {
					lblMinimize.setIcon(new ImageIcon(getClass().getResource("/icon_resources/Minimize.png")));
					frame.setExtendedState(JFrame.ICONIFIED);
				}
				
			});
		}
		return lblMinimize;
	}
	private JPanel getContaintPanel() {
		if (ContaintPanel == null) {
			ContaintPanel = new JPanel();
			ContaintPanel.setBackground(new Color(255,0,0,80));
			ContaintPanel.setBounds(0, 28,550,342);
			ContaintPanel.setLayout(null);
		}
		return ContaintPanel;
	}
	private JLabel getLblLogin() {
		if (lblLogin == null) {
			lblLogin = new JLabel("LogIn");
			lblLogin.setFont(new Font("Tahoma", Font.BOLD, 14));
			lblLogin.setForeground(Color.CYAN);
			lblLogin.setBounds(79, 4, 46, 18);
		}
		return lblLogin;
	}
}
